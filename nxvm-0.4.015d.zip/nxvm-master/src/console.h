/* Copyright 2012-2014 Neko. */

#ifndef NXVM_CONSOLE_H
#define NXVM_CONSOLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Entry point of NXVM console */
void consoleMain();

#ifdef __cplusplus
}/*_EOCD_*/
#endif

#endif
