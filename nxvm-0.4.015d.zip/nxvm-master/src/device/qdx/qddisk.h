/* Copyright 2012-2014 Neko. */

#ifndef NXVM_QDDISK_H
#define NXVM_QDDISK_H

#ifdef __cplusplus
extern "C" {
#endif

void qddiskInit();

#ifdef __cplusplus
}/*_EOCD_*/
#endif

#endif
