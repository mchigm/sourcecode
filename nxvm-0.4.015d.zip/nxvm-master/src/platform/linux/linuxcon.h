/* Copyright 2012-2014 Neko. */

#ifndef NXVM_LINUXCON_H
#define NXVM_LINUXCON_H

#ifdef __cplusplus
/*extern "C" {*/
#endif

void lnxcDisplaySetScreen();
void lnxcDisplayPaint();
void lnxcStartMachine();

#ifdef __cplusplus
/*}_EOCD_*/
#endif

#endif
