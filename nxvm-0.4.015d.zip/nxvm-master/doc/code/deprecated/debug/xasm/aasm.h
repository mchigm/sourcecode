/* This file is a part of NXVM project. */

#ifndef NXVM_AASM_H
#define NXVM_AASM_H

#include "../vglobal.h"

t_nubitcc aasm(const t_string stmt, t_nubit16 seg, t_nubit16 off);

#endif
