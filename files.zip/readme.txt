WWER-1000 Reactor Simulator
===========================

Before installing this software, please read the License Agreement (license.txt).


To start the Simulator:

1. Go to the root directory
   of CD "WWER-1000 Reactor Simulator".

2. Double click on the icon 'Run' 
   or execute the file 'RUN.EXE'. 

3. While executing, the Simulator software will create temporary files  
   in your system temporary files directory.

4. After finishing the Simulator execution all created temporary files  
   will be deleted.


For additional information, please, refer to the Workshop handout material and simulator exercises manual.


For further information, please, refer to:

ENIKO TSO
Russian Federation, 115409, Moscow, Kashirskoe shosse, 31. MEPhI, ENIKO TSO
Tel. +7-095-323-9599
Fax. +7-095-324-0993
Web page: http://www.eniko.ru
e-mail: contact@eniko.ru
