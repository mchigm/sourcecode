#!/bin/sh
cd software
java -Xms100M -Xmx512M -jar Janis.jar
cd ..
